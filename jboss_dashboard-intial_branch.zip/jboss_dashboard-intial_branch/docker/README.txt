To capture current instance health state of an instance
127.0.0.1:8000/api/current_state/?inst_name=weiss-apps_s01

To capture current instance health state of an appsuite
127.0.0.1:8000/api/current_state/?app_name=weiss-apps

To get the latest instance health data from database
127.0.0.1:8000/api/running_state/?inst_name=weiss-apps_s01

To get the latest instance health data from database for appsuite
127.0.0.1:8000/api/running_state/?app_name=weiss-apps


To access datasource health qirh instance and DS filter
http://127.0.0.1:8000/api/ds_state/?inst_name=weiss-apps_s01&ds_name=PostgresDS


Using CURL to make calls.
 curl 'http://localhost:9990/management/core-service/platform-mbean/type/threading/?operation=resource&name=thread-count&include-runtime=true' --digest -u readonly:Readonly@123
