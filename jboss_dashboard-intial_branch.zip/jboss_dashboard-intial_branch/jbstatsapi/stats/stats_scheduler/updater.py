from apscheduler.schedulers.background import BackgroundScheduler
from stats.api.views import _get_all_apps_health

def start():
    schduler = BackgroundScheduler()
    schduler.add_job(_get_all_apps_health, "interval", minutes=5, id="updater_001", replace_existing=True)
    schduler.start()