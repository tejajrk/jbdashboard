from django.shortcuts import render

# Create your views here.
from rest_framework import status, views
from rest_framework.response import Response
from rest_framework.decorators import api_view
from stats.api.serializers import InstanceHealthSerializer
from requests import Session
import os, json

@api_view(["GET"])
def get_inst_state(request):
    pass