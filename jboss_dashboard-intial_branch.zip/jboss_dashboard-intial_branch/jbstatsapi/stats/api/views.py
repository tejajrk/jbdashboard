import logging

from rest_framework.pagination import PageNumberPagination
logger = logging.getLogger(__name__)

from django.db.models.query import QuerySet
from rest_framework import viewsets, generics
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly, IsAdminUser
from rest_framework.generics import GenericAPIView

from stats.api.serializers import AppSuiteSerializer, InstanceSerializer, InstanceHealthSerializer, CurentInstanceHealthSerializer, DataSourceStateSerializer
from stats.models import InstanceHealth, DataSourceState
from rest_framework import serializers
import json
from stats.models import AppSuites, Instances, InstanceHealth
from stats.api.jb_getter import get_inst_health


class StandardResultsSetPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100

class AppsViewSet(viewsets.ModelViewSet):
    queryset = AppSuites.objects.all()
    serializer_class = AppSuiteSerializer

    # def perform_create(self, serializer):
    #     print(self.request.data['app_name'])
    #     serializer.is_valid(raise_exception=True)
    #     serializer.save(name=self.request.data['app_name'])


class InstancesViewSet(viewsets.ModelViewSet):
    queryset = Instances.objects.all().prefetch_related('app_name')
    serializer_class = InstanceSerializer

# class GetInstanceHealthViewSet(viewsets.ReadOnlyModelViewSet):


class GetInstanceHealthViewSet(generics.ListAPIView):
    serializer_class = InstanceHealthSerializer
    pagination_class = StandardResultsSetPagination
    logger.info("Under instance health view set")

    def get_queryset(self):
        # keys = self.kwargs.keys()
        app_name = self.request.query_params.get('app_name', None)
        inst_name = self.request.query_params.get('inst_name', None)
        records = self.request.query_params.get('records', None)
        queryset = None
        if app_name is not None:
            if records == 'all':
                queryset = InstanceHealth.objects.filter(app_name=app_name).prefetch_related(
                    'inst_name', 'app_name').order_by('-id')
                return queryset
            else:
                inst_count = Instances.objects.filter(
                    app_name=app_name).count()
                if inst_count >= 1:
                    queryset = InstanceHealth.objects.filter(app_name=app_name).prefetch_related(
                        'inst_name', 'app_name').order_by('-id')[:inst_count]
                return queryset
        if inst_name is not None:
            if records == 'all':
                queryset = InstanceHealth.objects.filter(inst_name=inst_name).prefetch_related(
                    'inst_name', 'app_name').order_by('-id')
            else:
                queryset = InstanceHealth.objects.filter(inst_name=inst_name).prefetch_related(
                    'inst_name', 'app_name').order_by('-id')
            #print (queryset.all())
            # to fetch single record
            # queryset = (queryset[0],)

            return queryset
        else:
            queryset = InstanceHealth.objects.all().prefetch_related(
                'inst_name', 'app_name').order_by('-id')
            return queryset


class CurentInstanceHealthViewSet(generics.ListCreateAPIView):
    logger.info("step1")
    serializer_class = CurentInstanceHealthSerializer

    def get_queryset(self):
        queryset = None
        logger.info("Getting instance health")
        app_name = self.request.query_params.get('app_name', None)
        inst_name = self.request.query_params.get('inst_name', None)
        if app_name is not None:
            logger.info("Getting instance health inside if condition")
            get_inst_health(app=app_name)
            queryset = InstanceHealth.objects.filter(app_name=app_name).prefetch_related(
                'inst_name', 'app_name').order_by('-id')[:1]
        if inst_name is not None:
            # app_name = AppSuites.objects.filter(instances=inst_name).prefetch_related('app_name').order_by('-id')[:1]
            get_inst_health(inst_name=inst_name)
            queryset = InstanceHealth.objects.filter(inst_name=inst_name).prefetch_related(
                'inst_name', 'app_name').order_by('-id')[:1]
        return queryset


class GetDataSourceViewSet(generics.ListCreateAPIView):
    logger.info("step1")
    serializer_class = DataSourceStateSerializer
    pagination_class = StandardResultsSetPagination

    def get_queryset(self):
        queryset = None
        logger.info("Getting instance health")
        app_name = self.request.query_params.get('app_name', None)
        inst_name = self.request.query_params.get('inst_name', None)
        ds_name = self.request.query_params.get('ds_name', None)
        if app_name is not None:
            if ds_name is not None:
            # get_inst_health(app=app_name)
            # queryset = DataSourceState.objects.filter(app_name=app_name).prefetch_related(
            #     'inst_name', 'app_name').order_by('-id')[:1]
                queryset = DataSourceState.objects.filter(app_name=app_name, ds_name=ds_name).select_related(
                    'inst_name', 'app_name').order_by('-id')[:1]
            else:
                queryset = DataSourceState.objects.filter(app_name=app_name).prefetch_related(
                    'inst_name', 'app_name').order_by('-id')
        if inst_name is not None:
            if ds_name is not None:
            # get_inst_health(app=app_name)
            # queryset = DataSourceState.objects.filter(app_name=app_name).prefetch_related(
            #     'inst_name', 'app_name').order_by('-id')[:1]
                queryset = DataSourceState.objects.filter(inst_name=inst_name, ds_name=ds_name).select_related(
                    'inst_name', 'app_name').order_by('-id')
            # app_name = AppSuites.objects.filter(instances=inst_name).prefetch_related('app_name').order_by('-id')[:1]
            # get_inst_health(inst_name=inst_name)
            else:                
                queryset = DataSourceState.objects.filter(inst_name=inst_name).prefetch_related(
                    'inst_name', 'app_name',).order_by('-id').distinct() #.distinct('ds_name') supported only by postgreSql
        return queryset

def _get_all_apps_health():
    logger.info('Invoking get all apps health')
    get_inst_health(app='all')