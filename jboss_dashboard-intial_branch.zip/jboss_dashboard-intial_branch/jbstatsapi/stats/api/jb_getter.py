import urllib3


import requests
from requests.auth import HTTPDigestAuth
# from requests import auth
import yaml
import os
import json
from django.conf import settings
from stats.models import AppSuites, Instances, InstanceHealth, DataSourceState
from stats.api.serializers import InstanceHealthSerializer
from stats.api.views import logger
from concurrent import futures

import http.client as httplib

# httplib.HTTPConnection.debuglevel = 2

ss = requests.Session()
ss.verify = False
requests.packages.urllib3.disable_warnings(
    urllib3.exceptions.InsecureRequestWarning)
if settings.IS_BASIC_AUTH:
    ss.auth = ('readonly', 'Readonly@123')
    ss.headers = {"Content-type": "application/json"}
else:
    ss.auth = HTTPDigestAuth('readonly', 'Readonly@123')
    ss.headers = {"Content-type": "application/json",
                #   "accept": "application/json",
                  "WWW-Authenticate": 'Digest realm="ManagementRealm'}
ss.timeout = 2
jb_health_json = json.load(
    open(os.path.join(os.path.dirname(__file__), "app_conf", "jboss-health.json")))
test = dict

def get_instance_list(app):
    instances = None
    if app == 'all':
        instances = Instances.objects.all().prefetch_related('app_name')
    else:
        instances = Instances.objects.filter(
                app_name=app).prefetch_related('app_name')
    return instances

def get_conn_url(hostname, port, request_type):
    if settings.IS_HTTPS:
        conn_url = jb_health_json[request_type].replace(
                    'hostname', hostname).replace('port', port)
    else:
        conn_url = jb_health_json[request_type].replace(
                    'hostname', hostname).replace('port', port).replace('https', 'http')
    return conn_url

def get_data(conn_url, **kwargs)    :
    status = None
    try:
        result = ss.get(conn_url, auth=ss.auth, stream=True, timeout=2)
        if result.status_code == 200:
            # print(json.loads(result.content))
            status = result.json()
        else:
            print(result.content)
            status = result.json()
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        # logger.info(app_name, inst_name, status)
    if status == None:
        status = 'not_reachable'
    return status    

def get_data_threaded(conn_url,  **kwargs):
    status = None
    with futures.ThreadPoolExecutor() as executor:
        exec = executor.submit(get_data, conn_url, **kwargs)
        status  = exec.result()
        return status

def get_ds_health(hostname, port):
    ds_name = 'none'
    active_count = -1
    available_count = -1
    average_creation_time = -1
    in_use_count = -1
    conn_url = get_conn_url(hostname, port, 'get_ds_stats')
    ds_data = get_data_threaded(conn_url)
    for data in ds_data:
        if data['address'][1]['data-source'] == 'ExampleDS':
            ds_data.pop(ds_data.index(data))
    # print(ds_data)
    ds_data_list = []
    if len(ds_data) < 0:
        return None
    else:
        for data in ds_data:
            data_dict = {}
            data_dict['ds_name'] = data['address'][1]['data-source']
            data_dict['active_count'] = data['result']['ActiveCount']
            data_dict['available_count'] = data['result']['AvailableCount']
            data_dict['average_creation_time'] = data['result']['AverageCreationTime']
            data_dict['in_use_count'] = data['result']['InUseCount']
            ds_data_list.append(data_dict)
    return ds_data_list
    



def get_current_health(hostname, port):
    gc_count = -1
    jboss_version = 'not_reachable'
    thread_count = 0
    heap_used = 0
    heap_max = 0
    non_heap_used = 0
    non_heap_max = 0
    conn_url = get_conn_url(hostname, port, 'server_health')
    print(conn_url)
    inst_status = get_data_threaded(conn_url)
    if inst_status != 'not_reachable':
        conn_url = get_conn_url(hostname, port, 'get_gc_data')
        gc_status = get_data_threaded(conn_url)
        if gc_status != "not_reachable":
            gc_count = gc_status['name']['PS_MarkSweep']['collection-count']
        else:
            gc_count = -1
        conn_url = get_conn_url(hostname, port, 'get_version')
        version_data = get_data_threaded(conn_url)
        if version_data != "not_reachable":
            jboss_version = version_data
        conn_url = get_conn_url(hostname, port, 'get_thread_data')   
        thread_data = get_data_threaded(conn_url) 
        if thread_data != "not_reachable":
            thread_count = thread_data['thread-count']
        conn_url = get_conn_url(hostname, port, 'get_mem_data')
        mem_data = get_data_threaded(conn_url)
        if mem_data != "not_reachable":
            heap_used = int(mem_data['heap-memory-usage']['used']/1024/1024)
            heap_max = int(mem_data['heap-memory-usage']['max']/1024/1024)
            non_heap_used = int(mem_data['non-heap-memory-usage']['used']/1024/1024)
            non_heap_max = int(mem_data['non-heap-memory-usage']['max']/1024/1024)




    return inst_status, gc_count, jboss_version, thread_count, heap_used, heap_max, non_heap_used, non_heap_max

def get_inst_health(**kwargs):
    if 'app' in kwargs.keys():
        app = kwargs['app']
        instances = get_instance_list(app)
        print(instances)
        if instances == None:
            return (404)
        for instance in instances:
            app_name, inst_name, hostname, port = instance.app_name_id, instance.inst_name, instance.hostname, str(instance.https_mgmt_port)
            inst_status, gc_count, jboss_version, thread_count, heap_used, heap_max, non_heap_used, non_heap_max = get_current_health(hostname, port)
            InstanceHealth.objects.create(
            app_name=instance.app_name, inst_name=instance, 
            running_state=inst_status, full_gc_count=gc_count, 
            jboss_version=jboss_version, thread_count=thread_count,
            heap_used=heap_used, heap_max=heap_max,
            non_heap_used=non_heap_used, non_heap_max=non_heap_max)

            if inst_status != 'not_reachable':
                ds_data_list = get_ds_health(hostname, port)
                if ds_data_list != 'none':
                    for ds_data in ds_data_list:
                        DataSourceState.objects.create(
                            app_name=instance.app_name, 
                            inst_name=instance,ds_name=ds_data['ds_name'],
                            active_count=ds_data['active_count'],
                            available_count=ds_data['available_count'],
                            average_creation_time=ds_data['average_creation_time'],
                            in_use_count=ds_data['in_use_count']
                        )

    if 'inst_name' in kwargs.keys():
        inst_name = kwargs['inst_name']
        instance = Instances.objects.get(inst_name=inst_name)
        app_name, inst_name, hostname, port = instance.app_name_id, instance.inst_name, instance.hostname, str(instance.https_mgmt_port)
        # app_object = AppSuites.objects.filter(app_name=app_name)
        inst_status, gc_count, jboss_version, thread_count, heap_used, heap_max, non_heap_used, non_heap_max = get_current_health(hostname, port)
        InstanceHealth.objects.create(
            app_name=instance.app_name, inst_name=instance, 
            running_state=inst_status, full_gc_count=gc_count, 
            jboss_version=jboss_version, thread_count=thread_count,
            heap_used=heap_used, heap_max=heap_max,
            non_heap_used=non_heap_used, non_heap_max=non_heap_max)
        
        if inst_status != 'not_reachable':
            ds_data_list = get_ds_health(hostname, port)
            if ds_data_list != 'none':
                for ds_data in ds_data_list:
                    DataSourceState.objects.create(
                        app_name=instance.app_name, 
                        inst_name=instance,ds_name=ds_data['ds_name'],
                        active_count=ds_data['active_count'],
                        available_count=ds_data['available_count'],
                        average_creation_time=ds_data['average_creation_time'],
                        in_use_count=ds_data['in_use_count']
                    )