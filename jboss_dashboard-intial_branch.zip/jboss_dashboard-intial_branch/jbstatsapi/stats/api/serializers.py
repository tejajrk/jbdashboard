from rest_framework import serializers
from rest_framework.validators import UniqueValidator
from stats.models import AppSuites, Instances, InstanceHealth, DataSourceState


class InstanceSerializer(serializers.ModelSerializer):
    # inst_name = serializers.CharField()
    # # app_id = serializers.IntegerField()
    # app_name = serializers.CharField()
    # hostname = serializers.CharField()
    # https_mgmt_port = serializers.IntegerField()
    # app_name = serializers.RelatedField(source='app_suites', many=True)

    class Meta():
        model = Instances
        fields = '__all__'
class AppSuiteSerializer(serializers.ModelSerializer):
    instances = InstanceSerializer(read_only=True, many=True) #many=True
    app_name = serializers.CharField(validators=[UniqueValidator(queryset=AppSuites.objects.all(), message="An app with that name already exists")])

    class Meta():
        model = AppSuites
        fields = '__all__'


    def __str__(self):
        return self.name



        # exclude = ['app_id']
# class InstanceDataSerializer(serializers.Serializer):
#     name = serializers.CharField()
#     app_name = serializers.SerializerMethodField('get_app_name')
#     hostname = serializers.CharField()
#     port = serializers.IntegerField()

#     class Meta():
#         model = Instances
#         exclude = ['app_id']

#     def get_app_name(self, instance_health):
#         return instance_health.app_suites.name
#     def __str__(self):
#         return self.name

class InstanceHealthSerializer(serializers.ModelSerializer):

#     app_name = serializers.SerializerMethodField('get_app_name')
#     # app_name = serializers.CharField()
#     inst_name = serializers.SerializerMethodField('get_inst_name')
#     running_state = serializers.CharField()
#     captured_at = serializers.DateTimeField()

    class Meta():
        model = InstanceHealth
        fields = '__all__'
#         exclude = ['app_id', 'inst_id']

#     def get_app_name(self, instance_health):
#         return instance_health.app_suites.name

#     def get_inst_name(self, instance_health):
#         return instance_health.instances.name


#select_related example
#employess  =  Employee.object.all().select_raelated('department')

class GetInstanceHealthSerializer(serializers.ModelSerializer):
    class Meta():
        model = InstanceHealth
        fields = '__all__'

class CurentInstanceHealthSerializer(serializers.ModelSerializer):
    class Meta():
        model = InstanceHealth
        fields = '__all__'

class DataSourceStateSerializer(serializers.ModelSerializer):

    class Meta():
        model = DataSourceState
        fields = '__all__'