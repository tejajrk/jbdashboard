from django.urls import include, path, re_path
from django.conf.urls import url
# from stats.api.views import get_app_list, get_app_inst_state
from stats.api import views as sv
from stats.api.views import GetInstanceHealthViewSet, GetDataSourceViewSet, CurentInstanceHealthViewSet
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register("apps", sv.AppsViewSet)
router.register("instances", sv.InstancesViewSet)
# router.register("get_inst_health", sv.GetInstanceHealthViewSet.as_view())
urlpatterns = [
    path("", include(router.urls)),
    path("current_state/", CurentInstanceHealthViewSet.as_view(), name="current_state" ),
    path("running_state/", GetInstanceHealthViewSet.as_view(), name='get_instance_health'),
    path("ds_state/", GetDataSourceViewSet.as_view(), name='get_ds_health'),
    # path("current-state/<str:app>", CurentInstanceHealthViewSet.as_view(), name="current_state" ),
    
]