from django.db import models

# Create your models here.
class AppSuites(models.Model):
    app_name = models.CharField(max_length=50, blank=False, unique=True)
    def __str__(self):
        return self.app_name
class Instances(models.Model):
    inst_name = models.CharField(max_length=100, blank=False, unique=True)
    hostname = models.CharField(max_length=100, blank=False)
    https_mgmt_port = models.IntegerField(blank=False)
    app_name = models.ForeignKey(AppSuites, on_delete=models.CASCADE, related_name='instances', to_field='app_name')


    def __str__(self):
        return self.inst_name

class DataSourceState(models.Model):
    ds_name = models.CharField(max_length=500, blank=False, unique=False, default='ExampleDS')
    app_name = models.ForeignKey(AppSuites, on_delete=models.CASCADE, related_name='app', to_field='app_name')
    inst_name = models.ForeignKey(Instances, on_delete=models.CASCADE, related_name='instance', to_field='inst_name')
    active_count = models.IntegerField()
    available_count = models.IntegerField()
    average_creation_time = models.IntegerField()
    in_use_count = models.IntegerField()
    # max_size = models.Sum('available_count', 'in_use_count')
    captured_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.inst_name}_{self.ds_name}"
class InstanceHealth(models.Model):
    running_state = models.CharField(max_length=500, blank=False, default='not_reachable')
    app_name = models.ForeignKey(AppSuites, on_delete=models.CASCADE, related_name='apps', to_field='app_name')
    inst_name = models.ForeignKey(Instances, on_delete=models.CASCADE, related_name='instances', to_field='inst_name')
    # ds_name = models.ForeignKey(DataSourceState, on_delete=models.CASCADE, related_name='datasource', to_field='ds_name')
    full_gc_count = models.IntegerField(blank=False)
    jboss_version = models.CharField(max_length=100, blank=False, default='not_reachable')
    thread_count = models.IntegerField(blank=False, default=0)
    heap_used = models.IntegerField(blank=False, default=0)
    heap_max = models.IntegerField(blank=False, default=0)
    non_heap_used = models.IntegerField(blank=False, default=0)
    non_heap_max = models.IntegerField(blank=False, default=0)
    captured_at = models.DateTimeField(auto_now_add=True)




