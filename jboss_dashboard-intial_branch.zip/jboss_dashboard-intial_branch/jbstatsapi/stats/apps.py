from django.apps import AppConfig


class StatsConfig(AppConfig):
    name = 'stats'
    print('starting config')

    def ready(self):
        print("starting scheduler.....")
        from .stats_scheduler import updater
        updater.start()

