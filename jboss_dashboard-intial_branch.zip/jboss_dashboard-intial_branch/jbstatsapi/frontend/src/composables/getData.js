import { ref, torefs } from 'vue'
const getData = (uri) => {

        const dataList = ref([])
        const error = ref(null)
        const myHeaders = new Headers()
        // myHeaders.append('Content-Type': 'Application/json')


        const load = async () => {
            try {
                let data = await fetch(uri, { method: 'GET', mode:'cors', 'origin': 'http://localhost:8080' } )
                // console.log(data)
                if(!data.ok) {
                    throw Error('No data available')
                }
                dataList.value = await data.json()
            }
            catch (err){
                error.value = err.message
                console.log(error.value)
            }
        }
        return {dataList, error, load}
}
export default getData