<template>
  <div >
      <!-- <div v-for="app in apps" :key="app.id">
        {{app.instances}}
      </div> -->

      <div class='app-list form-floating'>
        
        <select id="floatingSelect" class="form-select" aria-label="Default select example" @change="onChange($event)" >
          <option value="" disabled selected>select the app from drop down</option>
          <option v-for="app in apps" :key="app.id" :selectedApp="app">{{ app.app_name }}</option>
        </select>
        <!-- <label for="floatingSelect">Select The App To Get Health Info</label> -->
        
      </div>

      <div v-if="app" :app="app" class="table-responsive">
        <h3>Instance List for app {{app.app_name}} </h3>
      <!-- {{selectedApp}} -->
          <table class="instance_table table table-hover table-striped">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>APP_NAME</th>
                <th>INSTANCE_NAME</th>
                <th>HOST_NAME</th>
                <th>PORT</th>
              </tr>
            </thead>
            <tbody v-for="instance in app.instances" :key="instance.id">
              <tr>
                <td>{{instance.id}}</td>
                <!-- data-bs-container="body" data-bs-toggle="tooltip" data-bs-placement="top" title="Click Get Application Health" -->
                <td class="app_health" @click="getAppHealth(instance.app_name)">{{instance.app_name}}</td>
                <td class="instance_health" @click="getInstanceHealth(instance.inst_name)">{{instance.inst_name}}</td>
                <td>{{instance.hostname}}</td>
                <td>{{instance.https_mgmt_port}}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <InstanceHealth :instName="instName" v-if="instName"/>
        <AppHealth :appName="appName" v-if="appName"/>

  </div>
</template>

<script>
import { ref } from 'vue'
import InstanceHealth from '../components/InstanceHealth.vue'
import AppHealth from '../components/AppHealth.vue'

export default {
  props: ['apps'],
  components: { InstanceHealth, AppHealth },
  setup(props){
    const selectedApp = ref(null)
    const app = ref(null)
    const appName = ref(null)
    const instName = ref(null)
    const onChange = (event) => {
      selectedApp.value = event.target.value
      props.apps.forEach(element => {
        if (selectedApp.value){
        }
        
        if (selectedApp.value === element.app_name){
          appName.value = ''
          app.value = element
          instName.value = ''
        }
      })

    }
    const getInstanceHealth = (tempName) => {
      instName.value = tempName
      appName.value = ''
      // console.log(instName.value)
    }
    const getAppHealth = (tempName) =>{
      appName.value = tempName
      instName.value = ''
      // console.log(appName.value)
    }
    return{ onChange, app, getInstanceHealth, getAppHealth, instName, appName}
  }
}
</script>

<style>
.app-list{
  margin: 30px 300px 30px 300px;
}
.instance_table {
  margin-top: 40px;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  font-size: 12px;
  max-height: 300px;
}
.instance_health, .app_health {
  cursor: pointer;
}
.instance_health:hover, .app_health:hover {
  background: rgb(164, 214, 164);
}
.table-responsive {
  max-height: 400px;
  margin-top: 30px;
}
</style>