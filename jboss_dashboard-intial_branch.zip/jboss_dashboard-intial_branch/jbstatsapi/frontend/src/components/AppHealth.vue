<template>

    <div>
        <div class="general">
            <h1 :appName="appName">General Stats for App - {{ appName }}</h1>
        </div>
        <div v-if="instHealthList" :instHealthList="instHealthList" class="table-responsive">
            
            <div v-if="!error">
            <table class="instance_health_table table table-hover table-striped">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <!-- <th>APP_NAME</th> -->
                <th>INSTANCE_NAME</th>
                <th>RUNNING_STATUS</th>
                <th>THREAD_COUNT</th>
                <th>HEAP_USED</th>
                <th>HEAP_MAX</th>
                <th>NON_HEAP_USED</th>
                <th>NON_HEAP_MAX</th>
                <th>FULL_GC_COUNT</th>
                <th>CAPTURED_TIME</th>
              </tr>
            </thead>
            <tbody v-for="(result, index) in instHealthList.results" :key="result.id">
              <tr>
                <td>{{index + 1}}</td>
                <!-- data-bs-container="body" data-bs-toggle="tooltip" data-bs-placement="top" title="Click Get Application Health" -->
                <!-- <td>{{result.app_name}}</td> -->
                <td>{{result.inst_name}}</td>
                <td>{{result.running_state}}</td>
                <td>{{result.thread_count}}</td>
                <td>{{result.heap_used}}MB</td>
                <td>{{result.heap_max}}MB</td>
                <td>{{result.non_heap_used}}MB</td>
                <td>{{result.non_heap_max}}MB</td>
                <td>{{result.full_gc_count}}</td>
                <td>{{formatDate(result.captured_at)}}</td>
              </tr>
            </tbody>
          </table>

         </div>
            
        </div>
        <div class="general">
            <h1 :appName="appName">DataSource Stats for App - {{ appName }}</h1>
        </div>
        <div v-if="instDSHealthList" :instDSHealthList="instDSHealthList" class="table-responsive">
            
            <table class="instance_ds_health_table table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>INSTANCE_NAME</th>
                        <th>DS_NAME</th>
                        <th>ACTIVE_CONNECTIONS</th>
                        <th>AVAILABLE_CONNECTIONS</th>
                        <th>IN_USE_CONNECTIONS</th>
                        <th>AVG_CREATION_TIME</th>
                        <th>CAPTURED_AT</th>
                    </tr>
                </thead>
                <tbody v-for="(result, index) in instDSHealthList.results" :key="result.id">
                    <tr>
                        <td>{{index +1 }}</td>
                        <td>{{result.inst_name}}</td>
                        <td>{{result.ds_name }}</td>
                        <td>{{result.active_count }}</td>
                        <td>{{result.available_count }}</td>
                        <td>{{result.in_use_count }}</td>
                        <td>{{result.average_creation_time }}</td>
                        <td>{{ formatDate(result.captured_at) }}</td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
  
</template>

<script>
import { ref, watch, watchEffect } from 'vue'
import getData from '../composables/getData'
import moment from 'moment-timezone'

export default {
    props: ['appName'],
    setup(props){
        // const instName = ref('')
        const instHealthList = ref([])
        const instDSHealthList = ref([])
        // const dataList = ref(null)
        const error = ref(null)
        let uri = 'http://localhost:8000/api/running_state/?app=' + props.appName
        let dsUri = 'http://localhost:8000/api/ds_state/?app_name=' + props.appName
        const getInstaceHealth = async(uri) => {
            fetch(uri, { method: 'GET', mode:'cors', 'origin': 'http://localhost:8080' })
            .then(response => response.json())
            .then(data => instHealthList.value = data)
            .catch(err => error.value = err.message)
        }
        
        getInstaceHealth(uri)
        // load()
      const getInstDSHealth = async(dsUri) => {
            fetch(dsUri, { method: 'GET', mode:'cors', 'origin': 'http://localhost:8080' })
            .then(response => response.json())
            .then(data => {instDSHealthList.value = data
            console.log(data)})
            .catch(err => error.value = err.message)          
      }
      getInstDSHealth(dsUri)
        watch(() => props.appName, (newValue, OldValue) => {
            uri = 'http://localhost:8000/api/running_state/?app=' + props.appName
            dsUri = 'http://localhost:8000/api/ds_state/?app_name=' + props.appName
            getInstaceHealth(uri)
            getInstDSHealth(dsUri)
      })

      function formatDate(value){
          let myTimeZone = "America/Toronto"
          let myDateTimeFormat = "YYYY-MM-DD hh:mm:ss a z"
          if(value){
              return moment(String(value)).tz(myTimeZone).format(myDateTimeFormat)
          }
      }

        return { instHealthList,instDSHealthList, error, formatDate }
    }

}
</script>

<style>
.instance_health_table, .instance_ds_health_table {
margin-top: 40px;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  font-size: 12px;
  max-height: 300px;
}
.general {
    margin-top: 40px;
}
</style>