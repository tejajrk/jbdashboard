<template>
  <div class="home container">
    <!-- <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/> -->
    <h3>JBoss Central Console</h3>
    <div v-if="error"> {{ error }}</div>
    <div v-if="dataList.length">
      <AppSelect :apps="dataList"/>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import AppSelect from '../components/AppSelect.vue'
import getData from '../composables/getData'

export default {
  name: 'Home',
  components: { AppSelect },
  
  
  setup(){
   let uri  = 'http://localhost:8000/api/apps/'
    const { dataList, error, load } = getData(uri)
    load()
    // console.log(dataList)
    return { dataList, error}
  }
}
</script>

<style >

</style>
