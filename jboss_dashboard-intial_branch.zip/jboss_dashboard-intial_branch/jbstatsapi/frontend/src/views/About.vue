<template>
  <div class="about">
    <h1>A central JBoss console for high level monitoring</h1>
  </div>
</template>
